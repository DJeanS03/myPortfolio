export const myProjects = [
  {
    id: 1,
    tags: "Kubernetes / Research",
    name: "KubeRNP (UFBA/RNP)",
    photo:
      "https://github.com/hackinsdn/dashboard/blob/main/doc/img/dashboard-tela-inicial.png?raw=true",
    //photo: "https://media.licdn.com/dms/image/v2/D4D22AQFvRrpYSX2-ug/feedshare-shrink_2048_1536/B4DZl9ORmXHwA0-/0/1758742519263?e=1768435200&v=beta&t=yToo7qO2mjLtN-RGAGNNkk5L8VoxSbXc-C0UbAtCHpQ",
    link: "https://hackinsdn.ufba.br",
    status: "in__progress",
    state: "in__progress",
    translations: {
      en: {
        name: "KubeRNP (UFBA/RNP)",
        status: "In progress",
      },
      pt: {
        name: "KubeRNP (UFBA/RNP)",
        status: "Em progresso",
      },
    },
  },

  {
    id: 2,
    tags: "Web",
    name: "Coffee Delivery",
    photo:
      "https://github.com/DJeanS03/ToDo_app/assets/109162543/cbb902b2-f526-47f9-b0fb-82f368504a1c",
    link: "https://coffee-delivery-ignite-chi.vercel.app",
    status: "Concluded",
    state: "concluded",
    translations: {
      en: {
        name: "Coffee Delivery",
        status: "Concluded",
      },
      pt: {
        name: "Entrega de Café",
        status: "Concluído",
      },
    },
  },
  {
    id: 3,
    tags: "Web",
    name: "Pomodo Timer",
    photo:
      "https://github.com/DJeanS03/DJeanS03/assets/109162543/b0bd2663-63f6-4023-aa6b-5e81a60eb4a1",
    link: "https://pomodoro-timer-pearl-eta.vercel.app",
    status: "Concluded",
    state: "concluded",
    translations: {
      en: {
        name: "Pomodo Timer",
        status: "Concluded",
      },
      pt: {
        name: "Pomodo Timer",
        status: "Concluído",
      },
    },
  },
  {
    id: 4,
    tags: "Web",
    name: "ToDo app",
    photo:
      "https://github.com/DJeanS03/ToDo_app/assets/109162543/d37059c6-3ae9-4915-9a6e-2f2e18e0a7b5",
    link: "https://todo-app-xi-ruby.vercel.app",
    status: "Concluded",
    state: "concluded",
    translations: {
      en: {
        name: "ToDo app",
        status: "Concluded",
      },
      pt: {
        name: "Aplicativo de Tarefas",
        status: "Concluído",
      },
    },
  },
];
